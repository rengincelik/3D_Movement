::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
 This asset was shared by https://unityassetcollection.com

 Contact us for any questions:
 - Email: unityassetcollection@gmail.com
 - Telegram: @assetcollection or https://t.me/assetcollection
								
 Become a VIP member to download everything you want without limitations. 
 This also helps support our website to grow even stronger.
 For more detail: https://tinyurl.com/uac-vip-mem			
 Thank you very much.
::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

